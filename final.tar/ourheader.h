void foo(void); //function prototype
